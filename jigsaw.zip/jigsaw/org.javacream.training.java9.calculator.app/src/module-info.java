/**
 * 
 */
/**
 * @author Administrator
 *
 */
module org.javacream.training.java9.calculator.app {
	requires org.javacream.training.java9.calculator.util;
}