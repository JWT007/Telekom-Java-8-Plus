/**
 * 
 */
/**
 * @author Administrator
 *
 */
module org.javacream.training.java9.calculator.util {
	exports org.javacream.training.java9.calculator.util;
}