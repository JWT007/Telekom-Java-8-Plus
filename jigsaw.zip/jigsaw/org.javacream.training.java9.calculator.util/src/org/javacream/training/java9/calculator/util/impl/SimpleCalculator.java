package org.javacream.training.java9.calculator.util.impl;

public class SimpleCalculator {
	public double plus(double number1, double number2) {
		return number1 + number2;
	}
	public double minus(double number1, double number2) {
		return number1 + number2;
	}

}
